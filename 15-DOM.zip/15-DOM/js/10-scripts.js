// Generar HTML desde Javascript
