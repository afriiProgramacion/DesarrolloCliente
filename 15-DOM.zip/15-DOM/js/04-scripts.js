// querySelector() - Sintaxis CSS
