// Eliminar elementos del DOM
