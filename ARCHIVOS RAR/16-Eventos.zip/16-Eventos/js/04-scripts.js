// Eventos del propio formulario

// Vamos a mencionar un evento nada mas, submit, pero es bastante importante.

// Seleccionamos el formulario
const formulario = document.querySelector("#formulario");

// Le asignamos un listener
formulario.addEventListener("submit", (e) => {
  // Si quitamos  e.preventDefault(), al darle al botón va a hacer la acción por defecto para
  // ese elemento. En este caso el elemento es un boton submit y lo que hará será enviar
  // el form por post.
  e.preventDefault(); // Evitar lo que el navegador haría por defecto.
  console.log("buscando...");
  console.log(e);

  // Podemos obtener mas información..
  console.log(e.target.method); // Que método usa
  console.log(e.target.action); // Que action por default, hacia donde va...
});

// En vez de usar función de flecha anónima, podemos usar la declaración de función

formulario.addEventListener("submit", validarformulario);

function validarformulario() {
  e.preventDefault();
  console.log("buscando...");
}

// Para prevenir la acción por defecto necesitamos pasarle el evento a la función, 
// pero en validarformulario no tenemos parámetros. No es necesario, la función recibe 
// el evento como argumento por defecto.

formulario.addEventListener("submit", validarformulario);

function validarformulario(e) {
  e.preventDefault();
  console.log("buscando...");
}
